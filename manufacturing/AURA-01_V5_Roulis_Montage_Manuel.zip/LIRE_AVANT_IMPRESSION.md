# AURA-01 · V5 Roulis à socle plat · Montage manuel

Les projets Anycubic se trouvent dans Fabrication/Anycubic/Kobra_3. Commencer par AURA_V5_Premiers_essais.3mf pour les portées 608, les axes, le poignet et un doigt. Les projets Socle, Bras et Main contiennent ensuite les 52 pièces choisies pour le montage manuel. L'inventaire donne les quantités. A blanc égale zéro pour les pièces gardées en vue d'une motorisation ultérieure.

Les quatre projets ont été tranchés et réouverts avec un profil Kobra 3, buse de 0,4 mm et PETG. Vérifier le matériau, la plaque et la visserie réels au premier essai. Le trancheur signale des avis sur la température et le timelapse.

Préparer deux 608, un axe M8×55 et deux axes M5 à portée lisse, les rondelles et écrous correspondants, l'axe des doigts Ø2, les vis de phalanges, les vis de butée et deux M2×12 pour la retenue J7. Poser cette retenue par-dessous avant de fermer le poignet. Fixer le socle sur un support rigide et soutenir le bras pendant les premiers mouvements sans charge.

Le modèle Fusion associé est AURA-01_V5_Roulis_Montage_Manuel.f3d. L'empreinte du modèle est dans l'inventaire.
